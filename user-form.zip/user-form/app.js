const express = require('express');
const bodyParser = require('body-parser');
const app = express();

const submittedForms = [];

// Set up middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Serve HTML file
app.get('/user-form', (req, res) => {
  res.sendFile(__dirname + '/user-form.html');
});

// Handle form submission
app.post('/user-form', (req, res) => {
  const name = req.body.name;
  const dob = new Date(req.body.dob);
  const email = req.body.email;
  const phone = req.body.phone;

  // Basic front-end validation
  const age = Math.floor((new Date() - dob) / (365.25 * 24 * 60 * 60 * 1000));
  if (name && email && age >= 18) {
    const formData = { name, dob, email, phone };
    submittedForms.push(formData);
    res.redirect('/submitted-forms');
  } else {
    res.status(400).send('Invalid data');
  }
});

// Display all submitted forms
app.get('/submitted-forms', (req, res) => {
  let html = '<h1>Submitted Forms</h1>';
  submittedForms.forEach(form => {
    html += `
      <p>
        Name: ${form.name}, 
        Date of Birth: ${form.dob.toDateString()}, 
        Email: ${form.email}, 
        Phone: ${form.phone}
      </p>
    `;
  });
  res.send(html);
});

// Start the server
app.listen(process.env.PORT || 3000, () => console.log('Server started'));
